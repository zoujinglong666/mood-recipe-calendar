---
name: miniprogram-virtualpay-person
description: 微信小程序虚拟支付（道具直购 / 短系列虚拟商品 short_series_goods 模式）接入指引。当任务涉及开通激活虚拟支付、创建道具、服务端生成签名调起 requestVirtualPayment、发货推送与回调验签、查单、退款或结算费率时使用。覆盖真机与模拟器差异、签名算法（HMAC-SHA256）、环境位（env 0 正式 / 1 沙箱）、OfferID/AppKey 绑定、道具价格单位（元）等常见坑。
---

# 微信小程序虚拟支付接入指引（miniprogram-virtualpay-person）

## Overview

本 skill 提供微信小程序虚拟支付（数字权益 / 道具直购，常用 `short_series_goods` 短系列虚拟商品模式）的端到端接入知识：从商户开通激活，到道具配置、客户端调起、服务端签名、发货推送、查单对账、退款与结算费率。重点放在容易在真机才暴露、而模拟器看不出的问题（域名、环境位、签名、道具价格单位）。

详细签名算法、字段表与接口样例见 `references/virtualpay_reference.md`，实现时优先读取该文件。

## When to use this skill

在以下场景触发本 skill：

- 开通虚拟支付商户号、获取 OfferID / AppKey、配置沙箱/正式环境。
- 在微信支付后台创建道具（productId），配置价格、有效期、是否自动续费。
- 后端生成 `requestVirtualPayment` 的 `signData` / `paySig` / `signature` 三项签名。
- 前端调起支付、处理成功/取消/失败，以及按钮可购买性判定。
- 支付成功回调验签、发货推送（notify_deliver）、防重复发货。
- 主动查单（query_order）、弱网/未到账兜底。
- 退款、结算周期与费率核算。
- 真机报 `requestVirtualPayment:fail ...`、金额不一致、道具不存在、环境不匹配等排障。

## Core Capabilities

### 1. 开通与激活（Activation）

- 需**非个人主体**小程序，且服务类目符合虚拟商品要求；个人主体无法开通。
- 在微信支付 / 虚拟支付后台开通，拿到 **OfferID** 与 **AppKey**（AppKey 仅存服务端，绝不下发客户端）。
- 区分 **沙箱（env=1）** 与 **正式（env=0）** 两套 OfferID/配置；调试用沙箱，上线切正式。
- 客户端调起能力以 `typeof wx.requestVirtualPayment === 'function'`（uni 为 `uni.requestVirtualPayment`）是否存在为准，不同微信版本/基础库可能不支持。

### 2. 道具直购接入（Direct Purchase）

- 在 OfferID 下创建道具，得到 `productId`（如 `GZHY_30D`）。**道具价格单位填写「元」（如 9.9），不是「分」**——误填 990 会按 ¥990 扣款。
- 后端创建订单并生成签名参数（`signData` 含 `goodsPrice`，单位为「分」= 元×100）。
- `goodsPrice`（分）**必须与微信后台该道具价完全一致**，否则真机支付失败或查单金额校验报错。
- `productId`、`offerId`、`env` 三者必须属于同一配置；任一项不匹配即 fail。
- 前端可购买性应由**后端判定并返回 `msg`**（如「支付服务未配置」「会员道具 ID 配置后即可开通」），前端只负责展示，不要自行用 `platformItemId` 非空猜测能否支付。

### 3. 发货与推送（Delivery）

- 支付成功走服务端**回调验签**后发货，绝不可由客户端直接通知发货。
- 发货前调用 `notify_deliver`（发货推送），携带 `out_trade_no` / `wx_order_id` 等；用 `source_order_no` 唯一约束或幂等键防止回调重试重复发货。
- 真实到账以服务端发货通知为准，客户端 `requestVirtualPayment` 成功仅代表支付流程结束。

### 4. 查单（Order Query）

- 发货推送丢失或弱网时，后端定时主动 `query_order` 兜底（仅补最近一段时间、已等待至少一分钟的 PENDING 订单）。
- 查单需校验 `order_fee` 与本地 `goodsPrice`（分）一致，不一致视为异常。
- 客户端轮询订单状态直到 `DELIVERED`；超时提示「支付已完成，会员正在到账，请稍后刷新」。

### 5. 退款（Refund）

- 虚拟权益一经使用通常不支持无理由退款；未使用或到账异常走客服/退款流程。
- 退款需与微信支付侧退款接口及结算周期配合，避免重复退、超退。

### 6. 结算与费率（Settlement & Fees）

- 了解结算周期（通常 T+1 或按虚拟支付约定）、平台费率、分账规则。
- 账务以微信侧结算为准，本地仅做对账与异常告警。

## 关键排障清单（真机才暴露）

1. **模拟器 vs 真机**：开发者工具默认「不校验合法域名」且可模拟支付，故域名/签名/环境/道具价问题只在真机暴露。
2. **域名白名单**：`request`/`uploadFile`/`downloadFile` 合法域名需在公众平台配置为 HTTPS 且备案；否则真机 `url not in domain list`。
3. **env 不匹配**：代码 `env=0`（正式）但 OfferID 实为沙箱（或反之）→ fail。
4. **道具价单位**：后台填「元」，`signData.goodsPrice` 填「分」，二者等价核对。
5. **签名错误**：`paySig = HMAC-SHA256(appKey, "requestVirtualPayment&" + signData)`；`signature = HMAC-SHA256(session_key, signData)`；secret/session_key 不可下发明文。
6. **错误被吞**：`requestVirtualPayment` fail 回调返回 `{ errMsg, errCode }` 普通对象（非 Error 实例），前端需解析 `errMsg` 展示真实原因，否则只看到兜底文案。

## Resources

- `references/virtualpay_reference.md`：签名算法、signData 字段表、各接口（query_order / notify_deliver / 退款 / 结算）参数与样例、幂等与对账要点。

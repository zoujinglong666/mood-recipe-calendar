# 微信小程序虚拟支付 · 参考手册

> 适用模式：`short_series_goods`（短系列虚拟商品 / 道具直购）。其它模式（长期、订阅）字段与流程相近，以微信官方文档为准。

## 1. 接入模式与术语

| 概念 | 说明 |
|------|------|
| OfferID | 虚拟支付商户号，分为沙箱(env=1)与正式(env=0)两套 |
| AppKey | 签名密钥，**仅服务端保留**，不下发客户端 |
| productId | 道具 ID，如 `GZHY_30D`，须在 OfferID 下创建 |
| env | `0`=正式环境，`1`=沙箱环境 |
| goodsPrice | 商品价格，**单位：分**（元 × 100） |
| session_key | 用户登录态密钥，用于生成 `signature` |

## 2. 客户端调起

```js
wx.requestVirtualPayment({
  mode: 'short_series_goods',
  signData,        // JSON 字符串
  paySig,          // 服务端 HMAC
  signature,       // 服务端 HMAC（基于 session_key）
  success() {},
  fail(err) {
    // err = { errMsg: 'requestVirtualPayment:fail ...', errCode }
    // 注意：err 是普通对象，非 Error 实例，需读取 err.errMsg
  },
})
```

## 3. 签名算法（服务端）

```
paySig    = HMAC-SHA256(appKey,     "requestVirtualPayment&" + signData)
signature = HMAC-SHA256(sessionKey, signData)
```

- `signData` 为 JSON 字符串，字段顺序不敏感，但需与下方一致。
- 切勿把 AppKey / session_key 下发明文给客户端；客户端只拿到三项签名结果。

### signData 字段表

| 字段 | 类型 | 说明 |
|------|------|------|
| offerId | string | OfferID |
| buyQuantity | int | 购买数量，通常 1 |
| env | int | 0 正式 / 1 沙箱，须与 OfferID 环境一致 |
| currencyType | string | 固定 `CNY` |
| productId | string | 道具 ID，须在 OfferID 下存在 |
| goodsPrice | int | 价格，**分**；须与微信后台道具价一致 |
| outTradeNo | string | 商户订单号，全局唯一 |
| attach | string | 透传字段，常用订单号 |

### 一致性约束（违反即在真机 fail）

1. `goodsPrice`(分) == 微信后台该 `productId` 配置价(元)×100。
2. `productId` 属于当前 `offerId`。
3. `env` 与 OfferID 环境（沙箱/正式）一致。
4. AppKey 与 OfferID 匹配。

## 4. 订单与发货流程

```
创建订单(PENDING) → 生成签名 → 客户端调起 → 微信支付
   → 微信回调(验签) → 发货 notify_deliver → 订单 DELIVERED
   → (失败/弱网) 后端定时 query_order 兜底
```

### 防重复发货

- 用 `source_order_no` / `out_trade_no` 唯一约束或幂等键，回调解码重试时不重复加权益。
- 发货前判断订单状态：已 `DELIVERED` 直接返回；非 `PENDING`/`PAID` 拒绝。

### 查单 query_order

- 请求体：`{ openid, env, order_id }`，`pay_sig = HMAC-SHA256(appKey, "/xpay/query_order&" + body)`。
- 响应校验：`order.order_fee` 必须等于本地 `goodsPrice`（分），否则抛异常告警。
- `status >= 2 && <= 4` 视为已支付。

### 对账要点

- 仅补最近 N 天、且已等待至少 1 分钟的 PENDING 订单。
- 失败次数超阈值记录运营事件告警。

## 5. 退款与结算

- 退款：虚拟权益已使用一般不支持无理由退款；未使用/到账异常走客服工单 + 微信侧退款接口。
- 结算：以微信侧结算周期为准（常见 T+1），关注平台费率与分账规则。
- 本地仅做对账与异常告警，不自行计算应结算金额。

## 6. 客户端可购买性判定（推荐做法）

后端在商品列表接口随每条商品返回：

```
paymentAvailable: boolean
paymentUnavailableMsg: string   // 不可购买时的展示文案
```

判定逻辑（服务端，复用支付参数校验）：

- OfferID/AppKey 未配置 → `支付服务未配置`
- session_key 加密密钥未配置 → `支付登录态加密未配置`
- env 非 0/1 → `支付环境配置异常`
- productId 为空 → `会员道具 ID 配置后即可开通`
- 全部通过 → `paymentAvailable = true`

前端 `purchasable = paymentSupported && paymentAvailable`，文案直接消费后端 `paymentUnavailableMsg`；`paymentSupported` 仅判断 `uni.requestVirtualPayment` 是否存在（客户端能力），与后端配置无关。

## 7. 常见 fail 文案与含义

| errMsg 片段 | 含义 |
|------|------|
| `the productId ... not exist` | 道具未在 OfferID 下创建或 ID 不符 |
| `env not match` / 环境不符 | env 与 OfferID 沙箱/正式不一致 |
| 金额相关 | `goodsPrice` 与后台道具价不一致 |
| `cancel` | 用户主动取消，非故障 |
| `url not in domain list` | 域名白名单未配（属 request/uploadFile，非支付本身） |
